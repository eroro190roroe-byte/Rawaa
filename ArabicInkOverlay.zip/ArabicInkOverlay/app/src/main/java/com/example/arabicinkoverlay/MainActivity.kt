package com.example.arabicinkoverlay

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var historyList: ListView
    private lateinit var txtEmpty: TextView
    private lateinit var adapter: HistoryAdapter

    private val overlayLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (Settings.canDrawOverlays(this)) {
                requestNotificationsThenStart()
            } else {
                Toast.makeText(this, "لازم تعطي إذن الظهور فوق التطبيقات", Toast.LENGTH_LONG).show()
            }
        }

    private val fontPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri == null) return@registerForActivityResult
            val name = FontStore.import(this, uri)
            if (name == null) {
                Toast.makeText(this, "الملف مو خط صالح (لازم ttf أو otf)", Toast.LENGTH_LONG).show()
            } else {
                FontStore.select(this, name)
                Toast.makeText(this, "تمت إضافة الخط واختياره", Toast.LENGTH_SHORT).show()
                refreshHistory()
            }
        }

    private val notificationLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { startOverlay() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        historyList = findViewById(R.id.historyList)
        txtEmpty = findViewById(R.id.txtEmpty)
        adapter = HistoryAdapter(this)
        historyList.adapter = adapter

        findViewById<Button>(R.id.btnStartService).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                overlayLauncher.launch(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                )
            } else {
                requestNotificationsThenStart()
            }
        }

        findViewById<Button>(R.id.btnFont).setOnClickListener { showFontDialog() }

        findViewById<Button>(R.id.btnClearHistory).setOnClickListener {
            if (adapter.count == 0) return@setOnClickListener
            AlertDialog.Builder(this)
                .setMessage("تريد تمسح كل السجل؟")
                .setPositiveButton("مسح") { _, _ ->
                    HistoryStore.clear(this)
                    refreshHistory()
                }
                .setNegativeButton("إلغاء", null)
                .show()
        }

        historyList.setOnItemClickListener { _, _, position, _ ->
            val entry = adapter.getItem(position) ?: return@setOnItemClickListener
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("Recognized Text", entry.text))
            Toast.makeText(this, "تم النسخ", Toast.LENGTH_SHORT).show()
        }

        historyList.setOnItemLongClickListener { _, _, position, _ ->
            val entry = adapter.getItem(position) ?: return@setOnItemLongClickListener true
            AlertDialog.Builder(this)
                .setMessage("حذف هذا النص؟\n\n${entry.text}")
                .setPositiveButton("حذف") { _, _ ->
                    HistoryStore.delete(this, entry.id)
                    refreshHistory()
                }
                .setNegativeButton("إلغاء", null)
                .show()
            true
        }
    }

    override fun onResume() {
        super.onResume()
        refreshHistory()
    }

    private fun showFontDialog() {
        val fonts = FontStore.list(this)
        val labels = mutableListOf("الخط الافتراضي")
        labels += fonts.map { it.nameWithoutExtension }
        labels += "＋ إضافة خط من الجهاز"
        if (fonts.isNotEmpty()) labels += "حذف خط"

        AlertDialog.Builder(this)
            .setTitle("اختر الخط")
            .setItems(labels.toTypedArray()) { _, i ->
                when {
                    i == 0 -> { FontStore.select(this, null); refreshHistory() }
                    i <= fonts.size -> { FontStore.select(this, fonts[i - 1].name); refreshHistory() }
                    i == fonts.size + 1 -> fontPicker.launch(arrayOf("*/*"))
                    else -> showDeleteFontDialog()
                }
            }
            .show()
    }

    private fun showDeleteFontDialog() {
        val fonts = FontStore.list(this)
        AlertDialog.Builder(this)
            .setTitle("اختر الخط للحذف")
            .setItems(fonts.map { it.nameWithoutExtension }.toTypedArray()) { _, i ->
                FontStore.delete(this, fonts[i])
                refreshHistory()
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun refreshHistory() {
        val selected = FontStore.selectedName(this)
        findViewById<Button>(R.id.btnFont).text =
            "الخط: " + (selected?.substringBeforeLast('.') ?: "الافتراضي")
        adapter.typeface = FontStore.current(this)

        val items = HistoryStore.getAll(this)
        adapter.clear()
        adapter.addAll(items)
        txtEmpty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun requestNotificationsThenStart() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            startOverlay()
        }
    }

    private fun startOverlay() {
        ContextCompat.startForegroundService(this, Intent(this, FloatingInkService::class.java))
        // نخلي التطبيق بالخلفية حتى تبقى اللوحة العائمة فوق التطبيقات
        moveTaskToBack(true)
    }

    private class HistoryAdapter(context: Context) :
        ArrayAdapter<HistoryStore.Entry>(context, 0) {

        var typeface: Typeface? = null
        private val fmt = SimpleDateFormat("yyyy/MM/dd  HH:mm", Locale.US)

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val view = convertView
                ?: LayoutInflater.from(context).inflate(R.layout.item_history, parent, false)
            val entry = getItem(position)!!
            val txt = view.findViewById<TextView>(R.id.itemText)
            txt.typeface = typeface ?: Typeface.DEFAULT
            txt.text = entry.text
            view.findViewById<TextView>(R.id.itemTime).text = fmt.format(Date(entry.time))
            return view
        }
    }
}
