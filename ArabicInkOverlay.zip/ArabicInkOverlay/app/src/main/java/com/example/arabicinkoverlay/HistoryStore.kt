package com.example.arabicinkoverlay

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** سجل داخلي للنصوص المعالجة، محفوظ بـ SharedPreferences (الأحدث أولاً). */
object HistoryStore {

    data class Entry(val id: Long, val text: String, val time: Long)

    private const val PREFS = "ink_history"
    private const val KEY = "items"
    private const val MAX_ITEMS = 200

    @Synchronized
    fun getAll(context: Context): List<Entry> {
        val raw = prefs(context).getString(KEY, null) ?: return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                Entry(o.getLong("id"), o.getString("text"), o.getLong("time"))
            }
        }.getOrDefault(emptyList())
    }

    @Synchronized
    fun add(context: Context, text: String) {
        if (text.isBlank()) return
        val now = System.currentTimeMillis()
        val list = getAll(context).toMutableList()
        list.add(0, Entry(now, text, now))
        save(context, list.take(MAX_ITEMS))
    }

    @Synchronized
    fun delete(context: Context, id: Long) {
        save(context, getAll(context).filter { it.id != id })
    }

    @Synchronized
    fun clear(context: Context) {
        prefs(context).edit().remove(KEY).apply()
    }

    private fun save(context: Context, list: List<Entry>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("id", it.id).put("text", it.text).put("time", it.time))
        }
        prefs(context).edit().putString(KEY, arr.toString()).apply()
    }

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
}
