package com.example.arabicinkoverlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.common.model.RemoteModelManager
import com.google.mlkit.vision.digitalink.DigitalInkRecognition
import com.google.mlkit.vision.digitalink.DigitalInkRecognitionModel
import com.google.mlkit.vision.digitalink.DigitalInkRecognitionModelIdentifier
import com.google.mlkit.vision.digitalink.DigitalInkRecognizer
import com.google.mlkit.vision.digitalink.DigitalInkRecognizerOptions
import com.google.mlkit.vision.digitalink.RecognitionContext
import com.google.mlkit.vision.digitalink.WritingArea

class FloatingInkService : Service() {

    private lateinit var windowManager: WindowManager
    private var floatingView: View? = null
    private lateinit var drawingView: DrawingView
    private var recognizer: DigitalInkRecognizer? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startAsForeground()

        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        // الخدمة ما عدها ثيم، فنلف الـ Context بثيم التطبيق
        val themed = ContextThemeWrapper(this, R.style.Theme_ArabicInk)
        val view = LayoutInflater.from(themed).inflate(R.layout.layout_floating_widget, null)
        floatingView = view

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 100
            y = 200
        }
        windowManager.addView(view, params)

        drawingView = DrawingView(themed)
        view.findViewById<FrameLayout>(R.id.canvasContainer).addView(drawingView)

        setupDragging(view.findViewById(R.id.titleBar), view, params)
        setupOpacity(view)
        setupArabicMLKit()

        val txtResult = view.findViewById<TextView>(R.id.txtResult)
        view.findViewById<ImageButton>(R.id.btnClose).setOnClickListener { stopSelf() }
        view.findViewById<Button>(R.id.btnClear).setOnClickListener {
            drawingView.clearCanvas()
            txtResult.text = ""
        }
        view.findViewById<Button>(R.id.btnRecognize).setOnClickListener {
            processHandwriting(txtResult)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    private fun startAsForeground() {
        val channelId = "ink_overlay"
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(channelId, "اللوحة العائمة", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val stopIntent = android.app.PendingIntent.getService(
            this, 0,
            Intent(this, FloatingInkService::class.java).setAction("STOP"),
            android.app.PendingIntent.FLAG_IMMUTABLE
        )
        val notification: Notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("مصحح الخط العربي يشتغل")
            .setContentText("اللوحة العائمة فعالة")
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, notification)
        }
    }

    private fun setupOpacity(root: View) {
        val container = root.findViewById<FrameLayout>(R.id.canvasContainer)
        val seek = root.findViewById<SeekBar>(R.id.seekOpacity)
        val prefs = getSharedPreferences("ink_settings", MODE_PRIVATE)
        val strokePx = (2 * resources.displayMetrics.density).toInt()

        fun applyOpacity(percent: Int) {
            container.background = GradientDrawable().apply {
                setColor(Color.argb(percent * 255 / 100, 255, 255, 255))
                setStroke(strokePx, Color.parseColor("#2196F3"))
            }
        }

        val saved = prefs.getInt("opacity", 10)
        seek.progress = saved
        applyOpacity(saved)

        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                applyOpacity(progress)
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {
                prefs.edit().putInt("opacity", sb?.progress ?: 10).apply()
            }
        })
    }

    private fun setupDragging(handle: View, root: View, params: WindowManager.LayoutParams) {
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        handle.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x; startY = params.y
                    touchX = event.rawX; touchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX + (event.rawX - touchX).toInt()
                    params.y = startY + (event.rawY - touchY).toInt()
                    windowManager.updateViewLayout(root, params)
                    true
                }
                else -> false
            }
        }
    }

    private fun setupArabicMLKit() {
        val identifier = DigitalInkRecognitionModelIdentifier.fromLanguageTag("ar") ?: return
        val model = DigitalInkRecognitionModel.builder(identifier).build()

        RemoteModelManager.getInstance().download(model, DownloadConditions.Builder().build())
            .addOnSuccessListener {
                recognizer = DigitalInkRecognition.getClient(
                    DigitalInkRecognizerOptions.builder(model).build()
                )
                toast("تم تحميل نموذج الخط العربي بنجاح")
            }
            .addOnFailureListener {
                toast("فشل تنزيل نموذج العربية، تأكد من الإنترنت")
            }
    }

    private fun processHandwriting(txtResult: TextView) {
        val rec = recognizer
        if (rec == null) {
            toast("النموذج ما جاهز بعد، انتظر شوية")
            return
        }
        val ink = drawingView.inkBuilder.build()
        if (ink.strokes.isEmpty()) return

        // تمرير حجم منطقة الكتابة يحسّن دقة التعرف
        val context = RecognitionContext.builder()
            .setWritingArea(WritingArea(drawingView.width.toFloat(), drawingView.height.toFloat()))
            .build()

        rec.recognize(ink, context)
            .addOnSuccessListener { result ->
                val text = result.candidates.firstOrNull()?.text ?: return@addOnSuccessListener
                txtResult.typeface = FontStore.current(applicationContext) ?: Typeface.DEFAULT
                txtResult.text = text

                val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("Recognized Text", text))
                HistoryStore.add(applicationContext, text)
                toast("تم نسخ النص: $text")
            }
            .addOnFailureListener { toast("عذراً، تعذر التعرف على الخط") }
    }

    private fun toast(msg: String) =
        Toast.makeText(applicationContext, msg, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        super.onDestroy()
        floatingView?.let { runCatching { windowManager.removeView(it) } }
        floatingView = null
        recognizer?.close()
        recognizer = null
    }
}
