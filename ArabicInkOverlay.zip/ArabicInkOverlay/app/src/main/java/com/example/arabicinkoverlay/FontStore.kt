package com.example.arabicinkoverlay

import android.content.Context
import android.graphics.Typeface
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File

/** إدارة الخطوط اللي يضيفها المستخدم من الجهاز (ttf / otf). */
object FontStore {

    private const val PREFS = "ink_settings"
    private const val KEY = "font"
    private val EXTENSIONS = setOf("ttf", "otf")

    private var cachedName: String? = null
    private var cachedTypeface: Typeface? = null

    private fun dir(context: Context) =
        File(context.applicationContext.filesDir, "fonts").apply { mkdirs() }

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun list(context: Context): List<File> =
        dir(context).listFiles { f -> f.extension.lowercase() in EXTENSIONS }
            ?.sortedBy { it.name.lowercase() } ?: emptyList()

    fun selectedName(context: Context): String? =
        prefs(context).getString(KEY, null)?.takeIf { File(dir(context), it).exists() }

    fun select(context: Context, fileName: String?) {
        prefs(context).edit().apply {
            if (fileName == null) remove(KEY) else putString(KEY, fileName)
        }.apply()
    }

    /** الخط المختار حالياً، أو null إذا الافتراضي. */
    @Synchronized
    fun current(context: Context): Typeface? {
        val name = selectedName(context) ?: return null
        if (name == cachedName && cachedTypeface != null) return cachedTypeface
        val tf = load(File(dir(context), name)) ?: return null
        cachedName = name
        cachedTypeface = tf
        return tf
    }

    /** ينسخ الخط من الـ Uri لمجلد التطبيق. يرجع اسم الملف أو null إذا مو خط صالح. */
    fun import(context: Context, uri: Uri): String? {
        val resolver = context.applicationContext.contentResolver
        var name: String? = null
        resolver.query(uri, null, null, null, null)?.use { c ->
            val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && c.moveToFirst()) name = c.getString(idx)
        }
        val safeName = (name ?: "font_${System.currentTimeMillis()}.ttf")
            .replace(Regex("[\\\\/:*?\"<>|]"), "_")
        if (safeName.substringAfterLast('.', "").lowercase() !in EXTENSIONS) return null

        val target = File(dir(context), safeName)
        val ok = runCatching {
            resolver.openInputStream(uri)?.use { input ->
                target.outputStream().use { input.copyTo(it) }
            } ?: return null
            load(target) != null
        }.getOrDefault(false)

        if (!ok) {
            target.delete()
            return null
        }
        synchronized(this) { if (cachedName == safeName) cachedTypeface = null }
        return safeName
    }

    fun delete(context: Context, file: File) {
        file.delete()
        if (selectedName(context) == null && prefs(context).getString(KEY, null) == file.name) {
            select(context, null)
        }
        synchronized(this) { if (cachedName == file.name) { cachedName = null; cachedTypeface = null } }
    }

    private fun load(file: File): Typeface? {
        val tf = runCatching { Typeface.createFromFile(file) }.getOrNull() ?: return null
        // بعض إصدارات أندرويد ترجع الخط الافتراضي إذا الملف تالف
        return if (tf === Typeface.DEFAULT) null else tf
    }
}
